package com.usbank.px1.test;

import com.google.gson.annotations.Expose;

public class PS1Request {
	@Expose(serialize = false, deserialize = false) 
	private transient String testCaseNumber;

	public PS1Request() {
	}
	private RequestCriteria requestCriteria;
	
	public RequestCriteria getRequestCriteria() {
		return requestCriteria;
	}
	public void setRequestCriteria(RequestCriteria requestCriteria) {
		this.requestCriteria = requestCriteria;
	}
	
	@Override
	public String toString() {
		return "PS1Request [requestCriteria=" + requestCriteria + ", getRequestCriteria()=" + getRequestCriteria()
				+ "]";
	}
	public String getTestCaseNumber() {
		return testCaseNumber;
	}
	public void setTestCaseNumber(String testCaseNumber) {
		this.testCaseNumber = testCaseNumber;
	}
	
	


}
