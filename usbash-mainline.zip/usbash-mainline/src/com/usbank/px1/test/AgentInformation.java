package com.usbank.px1.test;

public class AgentInformation {

	public AgentInformation() {
		// TODO Auto-generated constructor stub
	}
	
	private Boolean sendEmailAsAgentFlag;
	private String bookOfBusinessId;
	private String associateId;
	private String fullName;
	private String title;
	private String phone;
	private String email;
	private String license;
	private String faceBookURL;
	private String agentPhotoUrl;
	private String twitterURL;
	private String linkedInURL;
	public Boolean getSendEmailAsAgentFlag() {
		return sendEmailAsAgentFlag;
	}
	public void setSendEmailAsAgentFlag(Boolean sendEmailAsAgentFlag) {
		this.sendEmailAsAgentFlag = sendEmailAsAgentFlag;
	}
	public String getBookOfBusinessId() {
		return bookOfBusinessId;
	}
	public void setBookOfBusinessId(String bookOfBusinessId) {
		this.bookOfBusinessId = bookOfBusinessId;
	}
	public String getAssociateId() {
		return associateId;
	}
	public void setAssociateId(String associateId) {
		this.associateId = associateId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	public String getFaceBookURL() {
		return faceBookURL;
	}
	public void setFaceBookURL(String faceBookURL) {
		this.faceBookURL = faceBookURL;
	}
	public String getAgentPhotoUrl() {
		return agentPhotoUrl;
	}
	public void setAgentPhotoUrl(String agentPhotoUrl) {
		this.agentPhotoUrl = agentPhotoUrl;
	}
	public String getTwitterURL() {
		return twitterURL;
	}
	public void setTwitterURL(String twitterURL) {
		this.twitterURL = twitterURL;
	}
	public String getLinkedInURL() {
		return linkedInURL;
	}
	public void setLinkedInURL(String linkedInURL) {
		this.linkedInURL = linkedInURL;
	}
	@Override
	public String toString() {
		return "AgentInformation [sendEmailAsAgentFlag=" + sendEmailAsAgentFlag + ", bookOfBusinessId="
				+ bookOfBusinessId + ", associateId=" + associateId + ", fullName=" + fullName + ", title=" + title
				+ ", phone=" + phone + ", email=" + email + ", license=" + license + ", faceBookURL=" + faceBookURL
				+ ", agentPhotoUrl=" + agentPhotoUrl + ", twitterURL=" + twitterURL + ", linkedInURL=" + linkedInURL
				+ "]";
	}	
	

}
