package com.usbank.px1.test;

public class OfferRecipientDetails {

	  private String alternateKey;
	  private String externalId;
	  private String acpi;
	  private String recipientType;
	  private String firstName;
	  private String lastName;
	  private MailingAddress mailingAddress;
	  private String emailAddress;
	  private String homePhone;
	  private String workPhone;
	  private String mobilePhone;
	  private String organizationName;
	  private String dateOfBirth;
	  private OrganizationMailingAddress organizationMailingAddress;
	public String getAlternateKey() {
		return alternateKey;
	}
	public String getAcpi() {
		return acpi;
	}
	public String getExternalId() {
		return externalId;
	}
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}
	public void setAcpi(String acpi) {
		this.acpi = acpi;
	}
	public void setAlternateKey(String alternateKey) {
		this.alternateKey = alternateKey;
	}
	public String getRecipientType() {
		return recipientType;
	}
	public void setRecipientType(String recipientType) {
		this.recipientType = recipientType;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public MailingAddress getMailingAddress() {
		return mailingAddress;
	}
	public void setMailingAddress(MailingAddress mailingAddress) {
		this.mailingAddress = mailingAddress;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getHomePhone() {
		return homePhone;
	}
	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}
	public String getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public OrganizationMailingAddress getOrganizationMailingAddress() {
		return organizationMailingAddress;
	}
	public void setOrganizationMailingAddress(OrganizationMailingAddress organizationMailingAddress) {
		this.organizationMailingAddress = organizationMailingAddress;
	}
	
	
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	@Override
	public String toString() {
		return "OfferRecipientDetails [alternateKey=" + alternateKey + ", externalId=" + externalId + ", acpi=" + acpi
				+ ", recipientType=" + recipientType + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", mailingAddress=" + mailingAddress + ", emailAddress=" + emailAddress + ", homePhone=" + homePhone
				+ ", workPhone=" + workPhone + ", mobilePhone=" + mobilePhone + ", organizationName=" + organizationName
				+ ", dateOfBirth=" + dateOfBirth + ", organizationMailingAddress=" + organizationMailingAddress + "]";
	}
      



}
