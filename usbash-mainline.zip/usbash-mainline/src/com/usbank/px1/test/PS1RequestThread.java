package com.usbank.px1.test;

import java.util.List;

import org.apache.log4j.Logger;

import com.usbank.sh.base.cmd.PX1HttpClient;

public class PS1RequestThread implements Runnable {
	private String testCaseID;
    private String endPointURL;
    private String requestBody;
    private List<String[]> headers;
    private boolean shouldRun;
    private Double runningAvg;
    private Double runTotal;
    private Double runCount = 0D;
    private Integer sleepInterval;

    private static Logger log =
        Logger.getLogger(PS1RequestThread.class);

    public PS1RequestThread(String testCaseID, String requestBody, String endPointURL, 
    						Double runTotal, List<String[]>headers, Integer sleepInterval) {
    	this.testCaseID		= testCaseID;
        this.requestBody 	= requestBody;
    	this.endPointURL    = endPointURL;
    	this.runTotal		= runTotal;
    	this.headers		= headers;
    	this.sleepInterval  = sleepInterval;
        shouldRun 			= true;
    }
    

    public void run() {
        debug ("hello world...");
        PX1HttpClient client = new PX1HttpClient(); 

        while (shouldRun) {
            long start = System.currentTimeMillis();
            
            try {
                debug ("now processing request...");
                
                client.post(endPointURL, headers, requestBody);
                runCount++;
                
                long finish = System.currentTimeMillis();
                long time = finish - start;
                debug ("Request took " + time + " milliseconds.");
                updateAvg(time);
                debug ("New average for this scenario is: " + runningAvg + " milliseconds.");
                Thread.sleep(sleepInterval);
                

            } catch (Exception e) {
                log.error("Exception caught during sleep interval",e);
            }
            
            // Either run forever or run until we've hit our run total
            if (runTotal > 0 && runCount <= runTotal) { shouldRun = false; }

        }
    }

    private void debug (String msg) {
        if (log.isDebugEnabled()) {
            log.error("Test Case:[" + this.testCaseID + "] - " + msg);
        }
    }

    /**
     * @return Returns the shouldRun.
     */
    public boolean isShouldRun() {
        return shouldRun;
    }

    
    /**
     * @param shouldRun The shouldRun to set.
     */
    public void setShouldRun(boolean shouldRun) {
        this.shouldRun = shouldRun;
    }

    private int count = 0;
    private void updateAvg (long thisAvg) {
        runningAvg = runningAverage(runningAvg,new Double(thisAvg),count);
        count++;
    }

    private static Double runningAverage(Double average,Double next,int count){
        if (count == 1 || average == null) {
            return next;
        }
        double nextvalue = next.doubleValue();
        double avg       = average.doubleValue();
        avg              = ( ( (double)(count-1) / (double)count ) * avg ) +
                             (( (1.0 / (double)count) * (double)nextvalue ));
        return new Double(avg);
    }
}
