package com.usbank.sh.base;

/**
 * USBashCommand provides the interface for a USBash
 * Command.

 */

public interface USBashCommand {
    
    public void init ( String cmdName, USBashBase shell ) 
        throws USBashCommandException;

    public void doCommand ( String[] args )
        throws USBashCommandException;

    public String getHelp ( String[] args );
    
    public String getUsage();
    
    public String getCommandName();
    
}
