package com.usbank.sh.base;

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import com.usbank.sh.base.cmd.Cmd_exit;
import com.usbank.sh.base.cmd.Cmd_help;

import jline.ArgumentCompletor;
import jline.Completor;
import jline.ConsoleReader;
import jline.FileNameCompletor;
import jline.SimpleCompletor;

/**
 * USBash provides the base implementation of a command interpreter.
 */

public class USBashBase implements USBashCmdTranslator {
    private String promptStr 		= null;
    private PrintStream out 		= null;
    private PrintStream err 		= null;
    private boolean loggedOn 		= false;
    private ConsoleReader reader 	= null;
    private Map<String,USBashCommand> commandMap;
    public static final String DEFAULT_SHELL_HISTORY = "/usbash_history.log";

    public void init (String promptStr, PrintStream out, PrintStream err) {
        this.promptStr = promptStr;
        this.out = out;
        this.err = err;
                
        commandMap = new HashMap<String,USBashCommand>();
        try {
            registerCommand ("exit", new Cmd_exit());
            registerCommand ("help", new Cmd_help());
        }
        catch (USBashCommandException e) {
            System.err.println("Unable to register commands");
        }
    }
    
    
    public void registerCommand ( String cmdName, USBashCommand cmd )
        throws USBashCommandException {
        commandMap.put(cmdName, cmd);
        cmd.init(cmdName, this);
    }
    
    public USBashCommand getCommand ( String cmdName ) {
        return (USBashCommand)commandMap.get(cmdName.toLowerCase());
    }
    
    public static String[] parseArgs (String arg)
        throws Exception {
        ArrayList<String> res = new ArrayList<String>();
        StringTokenizer quoteTok;
        boolean inQuote = false;

        arg = arg.trim();
        quoteTok = new StringTokenizer(arg, "\"", true);

        while(quoteTok.hasMoreTokens()){
            String elem = (String)quoteTok.nextElement();

            if(elem.equals("\"")){
                inQuote = !inQuote;
                continue;
            }

            if(inQuote){
                res.add(elem);
            } else {
                StringTokenizer spaceTok = new StringTokenizer(elem.trim());

                while(spaceTok.hasMoreTokens()){
                    res.add(spaceTok.nextToken());
                }
            }
        }

        if(inQuote){
            throw new Exception("Unbalanced quotation marks");
        }
        return (String[]) res.toArray(new String[0]);
    }
    
    public PrintStream getOutputStream () { return this.out; }
    public PrintStream getErrorStream() { return this.err; }
    public Iterator<String> getCommandNames() { return commandMap.keySet().iterator(); }
    public void setPrompt (String s) { this.promptStr = s; }

    public void doCommand (String line) {
        String[] args;
    
        try {
            args = parseArgs(line);
        } catch(Exception exc){
            out.println("Syntax error: " + exc.getMessage());
            return;
        }
        if(args.length != 0)
            doCommand(line, args);
    }

    public void doCommand (String cmdStr, String[] args) {
        USBashCommand cmd;
        String cmdName;
        
        cmdName = args[0];
        
        if (args.length == 0) {
            throw new IllegalArgumentException("Invalid argument:command=null");
        }
        
        try {
            cmd = this.getCommand(cmdName);
            if (cmd == null) {
                out.println("Not Implemented");
            } else {
                cmd.doCommand(args);
            }
        } catch (USBashCommandException e) {
            System.err.println("Caught shell exception:"+e.getMessage());
        }
    }

    // TODO: rework this
    public void run () {
        String input = null;

        while (true) {
            try {
                input = getInput(this.promptStr,true);
            } 
            catch ( EOFException e ) {
                break;
            } catch ( Exception e ) {
                err.println("Fatal error reading input line: " + e);
                e.printStackTrace(err);
                return;
            }
            
            if ( input == null || input.trim().length() == 0 )
                continue;

            this.doCommand(input);
        }
        out.println("Goodbye.");
    }
    
    public String getInput ( String prompt ) throws EOFException, IOException {
        return getInput(prompt,false);
    }
        
    // XXX TODO: Clean this up!
    private File getHistoryFile () {
        String fileName;
        File retVal;
        
        fileName = System.getProperty("shell-history-file");
        if (fileName == null || fileName.compareTo("")==0) {
            fileName = DEFAULT_SHELL_HISTORY;    
        }
        retVal = new File(fileName);
        return retVal;
    }
    
    public String getInput ( String prompt, boolean addToHistory ) 
        throws IOException {
        if (reader == null) {
            Completor[] c = new Completor[2];
            reader =  new ConsoleReader(getHistoryFile());
            c[0] = new SimpleCompletor((String[])commandMap.keySet()
                    .toArray(new String[0]));
            c[1] = new FileNameCompletor();
            ArgumentCompletor ac = new ArgumentCompletor(c);
            ac.setStrict(false);
            reader.addCompletor( ac );
        }
        return reader.readLine(prompt);
    }
    
    public String getPasswordInput (String prompt) throws IOException {
    	ConsoleReader temp = new ConsoleReader();
        return temp.readLine(prompt, new Character(' '));
    }
    
    public String getProperty (String name) {
        try {
            return System.getProperty(name);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    


    protected String getAuthStatus () {
        return (loggedOn)?"logged-on" : "logged-off";
    }
    
    public void shutdown () {
        // does jline's history file need tidying up here?
    }
}