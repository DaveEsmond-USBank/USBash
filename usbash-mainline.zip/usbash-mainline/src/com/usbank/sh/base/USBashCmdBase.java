package com.usbank.sh.base;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

public abstract class USBashCmdBase implements USBashCommand {

    protected String cmdName = null;
    protected USBashBase shellBase = null;
    private Map <String,Object> GLOBAL_MEMORY = new HashMap<String,Object>();

    private PrintStream out = null;
    public String getCommandName () { return cmdName; }
    public USBashBase getShell () { return shellBase; }
    
    public PrintStream getOutStream () {
        return this.getShell().getOutputStream();
    }

    public PrintStream getErrStream () {
        return this.getShell().getErrorStream();
    }

    public void init ( String cmdName, USBashBase shellBase ) 
        throws USBashCommandException {
        this.cmdName = cmdName;
        this.shellBase = shellBase;
    }

    public void doCommand ( String[] args )
        throws USBashCommandException {
        out.println("not implemented: " + this.cmdName);
    }

    public String getUsage() {
        return formatUsage(this,"");
    }  

    public String getHelp (String[] args) {
        return "";
    }
    
    public void saveObject (String key, Object o) {
    	GLOBAL_MEMORY.put(key, o);
    }

    public Object getObject (String key) {
    	return GLOBAL_MEMORY.get(key);
    }
    
    protected String formatUsage (USBashCommand cmd,
    		                      String usage) {
    	
    	return "\n\nUsage:\n\n    "
    	       + cmd.getCommandName()
    	       + " "
    	       + usage
    	       + "\n\n";
    }
}
