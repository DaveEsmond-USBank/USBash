package com.usbank.sh.base.cmd;

import java.io.PrintStream;

import org.apache.log4j.PropertyConfigurator;

import com.usbank.px1.test.Cmd_exec_ps1_test;
import com.usbank.sh.base.NormalExitException;
import com.usbank.sh.base.SigHandler;
import com.usbank.sh.base.USBashBase;
import com.usbank.sh.base.USBashCommand;
import com.usbank.sh.base.USBashCommandException;

/**
 */
public class USBash extends USBashBase {

    private PrintStream stdOut;
    
    public USBash(){
        this.stdOut         = null;
    }

    public void init(String promptStr, PrintStream out, PrintStream err){
        super.init(promptStr, out, err);
        this.stdOut = out;
    }
    
    public void registerCommands () throws USBashCommandException {
    	
    	registerCommand ("jsontest", new Cmd_jsontest());
    	registerCommand ("exec-ps1", new Cmd_exec_ps1_test());
    }
    
    public void doCommand (USBashCommand cmd, String[] args) 
        throws USBashCommandException {
        while (true) {
            try {
                cmd.doCommand(args);
            }
            catch (USBashCommandException e) {
            	stdOut.println("Command Exception:"+e.getMessage());
                e.printStackTrace();
            }
        }
    }
    

    
    public static void main (String[] args) {
        USBash fishell;
        fishell = null;
        System.setProperty("log4j.logger.org.jnp.interfaces.NamingContext",
                           "ERROR");
        PropertyConfigurator.configure(System.getProperties());

        try {
            fishell = new USBash();
            fishell.init("usbash::>", System.out, System.err);
            fishell.registerCommands();
            SigHandler.install(fishell, SigHandler.SIGNAL_INT);
            fishell.run();
        } 
        catch (NormalExitException e) {
            System.out.println("Goodbye.");
        } 
        catch ( Exception e ) {
            System.err.println("Unexpected exception: " + e);
            e.printStackTrace();
        } 
        finally {
            fishell.shutdown();
        }
    }
    
}
