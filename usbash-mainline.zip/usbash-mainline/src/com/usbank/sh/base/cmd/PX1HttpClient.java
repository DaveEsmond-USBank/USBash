package com.usbank.sh.base.cmd;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;

public class PX1HttpClient {

	public PX1HttpClient() {
	}
	

	public void post (String url, List<String[]>headers, String payload) {
        HttpClient client;
        HttpPost request;
        HttpResponse response;
        
        try {
        	client 	= HttpClientBuilder.create().build();
        	request 	= new HttpPost(url);

        	if (headers != null) {
	        	for (String[] header : headers) {
	                request.addHeader(header[0], header[1]);
	        	}
        	}
        	
        	StringEntity entity = new StringEntity(payload,ContentType.APPLICATION_JSON);
        	request.setEntity(entity);
        	
        	System.out.println("REQUEST:" + request);

            response = client.execute(request);

            BufferedReader br = new BufferedReader(
                             new InputStreamReader((response.getEntity().getContent())));

            String output;
            System.out.println("RESPONSE:\n");
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
		} 
        catch (ClientProtocolException e) 
        {
			e.printStackTrace();
		} 
        catch (IOException e) 
        {
			e.printStackTrace();
		}
    }
}
