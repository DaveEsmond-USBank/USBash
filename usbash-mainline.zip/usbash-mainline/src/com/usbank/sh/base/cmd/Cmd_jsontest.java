package com.usbank.sh.base.cmd;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.usbank.px1.test.AgentInformation;
import com.usbank.px1.test.MailingAddress;
import com.usbank.px1.test.OfferRecipientDetails;
import com.usbank.px1.test.OrganizationMailingAddress;
import com.usbank.px1.test.PS1Request;
import com.usbank.px1.test.RequestCriteria;
import com.usbank.sh.base.USBashCmdBase;
import com.usbank.sh.base.USBashCommandException;  

public class Cmd_jsontest extends USBashCmdBase {

	    public void doCommand ( String[] args ) throws USBashCommandException {
	    	
	    	RequestCriteria req = new RequestCriteria();
	    	req.setOfferType("PS1");
	    	req.setOfferProductType("CARDS");
	    	req.setQualifyingEvent("SF-1001");
	    	req.setPartnerCampaignId("ABC123");
	    	req.setPartnerLinkTag("cmpid%3Dem%3A326%3A202009%26A%3D0G3YB000%26C%3D9999999");
	    	req.setOfferCustomerType("CONSUMER");
	    	
	    	AgentInformation agent = new AgentInformation();	    	
	    	agent.setSendEmailAsAgentFlag(true);
	    	agent.setBookOfBusinessId("018283012983");
	    	agent.setAssociateId("128301828301923800");
	    	agent.setFullName( "Amy Agent");
	    	agent.setTitle("Lead Agent");
	    	agent.setPhone("(777) 777-7777");
	    	agent.setEmail("amy@agent.com");
	    	agent.setLicense("CA-1234151");
	    	agent.setFaceBookURL("https://www.facebook.com/01234567891011");
	    	agent.setAgentPhotoUrl("https://s3.amazonaws.com/campaign/1f36f0ac8/32069.jpg");
	    	agent.setTwitterURL ("https://twitter.com/agentAmy");
	    	agent.setLinkedInURL("https://www.linkedin.com/in/agentAmy/");
	    	req.setAgentInformation(agent);
	    	
	    	MailingAddress mAdd = new MailingAddress();
	    	mAdd.setAddressLine1("10684 EASTERN AVE");
	    	mAdd.setAddressLine2("");
	    	mAdd.setCity("WAYLAND");
	    	mAdd.setState("MI");
	    	mAdd.setZipCode("49348");
	    	
	    	OrganizationMailingAddress omAdd = new OrganizationMailingAddress();
	    	omAdd.setAddressLine1("");
	    	omAdd.setAddressLine2("");
	    	omAdd.setCity("");
	    	omAdd.setState("");
	    	omAdd.setZipCode("");
	    	
	    	OfferRecipientDetails ord = new OfferRecipientDetails();
	    	ord.setAlternateKey("4152155151WARD0101");
	    	ord.setEmailAddress("dave.esmond@usbank.com");
	    	ord.setFirstName("SHARON");
	    	ord.setLastName("JOHNSON");
	    	ord.setHomePhone("201.914.4183");
	    	ord.setMailingAddress(mAdd);
	    	ord.setMobilePhone("804.548.6859");
	    	ord.setOrganizationMailingAddress(omAdd);
	    	ord.setOrganizationName(cmdName);
	    	ord.setRecipientType("P");
	    	ord.setWorkPhone("201.914.4183");
	    	ord.setDateOfBirth("1967-03-01");
	    	req.setOfferRecipientDetails(ord);
	    	
	    	PS1Request ps1Req = new PS1Request();
	    	ps1Req.setRequestCriteria(req);
	    	
	        getOutStream().println("Request:" + ps1Req);
	        
	        Gson gson = new GsonBuilder().setPrettyPrinting().create();
	        String jsonString = gson.toJson(ps1Req);
	        getOutStream().println(jsonString);

	    } 

	    public String getUsage(){
	    	return formatUsage(this,"<arg1> <arg2>");
	    }

	    public String getHelp ( String[] args ) {
	        return "This is an example command.";
	    }
	}


/**
 * 
 * {
"requestCriteria": {
"offerType": "PS1",
"offerProductType": "CARDS",
"qualifyingEvent": "SF-1001",
"partnerCampaignId": "ABC123",
"partnerLinkTag": "cmpid%3Dem%3A326%3A202009%26A%3D0G3YB000%26C%3D9999999",
"offerCustomerType": "CONSUMER",
"agentInformation": {
  "sendEmailAsAgentFlag": true,
  "bookOfBusinessId": "018283012983",
  "associateId": 128301828301923800,
  "fullName": "Amy Agent",
  "title": "Lead Agent",
  "phone": "(777) 777-7777",
  "email": "amy@agent.com",
  "license": "CA-1234151",
  "faceBookURL": "https://www.facebook.com/01234567891011",
  "agentPhotoUrl": "https://s3.amazonaws.com/campaign/1f36f0ac8/32069.jpg",
  "twitterURL": "https://twitter.com/agentAmy",
  "linkedInURL": "https://www.linkedin.com/in/agentAmy/"
},
"offerRecipientDetails": {
  "alternateKey": "4152155151WARD0101",
  "recipientType": "P",
  "firstName": "SHARON",
  "lastName": "JOHNSON",
  "dateOfBirth": "1967-03-01",
  "mailingAddress": {
    "addressLine1": "10684 EASTERN AVE",
    "city": "WAYLAND",
    "state": "MI",
    "zipCode": 49348
  },
  "emailAddress": "dave.esmond@usbank.com",
  "homePhone": "201.914.4183",
  "workPhone": "201.914.4183",
  "mobilePhone": "804.548.6859",
  "organizationName": "ACME Windows",
  "organizationMailingAddress": {
    "addressLine1": "100 Main St. Apt 2J",
    "addressLine2": "P.O. Box 100",
    "city": "San Francisco",
    "state": "California",
    "zipCode": 94105,
    "countryCode": 840
  }
}
}
}
 */

