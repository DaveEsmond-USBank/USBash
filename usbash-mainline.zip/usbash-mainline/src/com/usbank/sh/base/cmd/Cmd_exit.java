package com.usbank.sh.base.cmd;

import com.usbank.sh.base.NormalExitException;
import com.usbank.sh.base.USBashCmdBase;

/**
 * USBash command for handling exit.
 */
public class Cmd_exit extends USBashCmdBase {

    public void doCommand ( String[] args ) {
        throw new NormalExitException();
    } 

    public String getUsage(){
        return formatUsage(this,"");
    }

    public String getHelp ( String[] args ) {
        return "exit - quits the shell";
    }
    
    
    
}
