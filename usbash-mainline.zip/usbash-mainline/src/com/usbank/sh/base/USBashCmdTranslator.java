package com.usbank.sh.base;

import java.util.Iterator;

/**
 * USBashCmdTranslator specifies the interface for a
 * command translator.

 */

public interface USBashCmdTranslator {
    public USBashCommand getCommand ( String command );
    public Iterator getCommandNames ();
    
}
