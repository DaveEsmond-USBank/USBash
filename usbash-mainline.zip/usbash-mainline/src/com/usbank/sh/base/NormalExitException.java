package com.usbank.sh.base;

import java.lang.RuntimeException;

public class NormalExitException 
  extends RuntimeException {
	private static final long serialVersionUID = -1L;
	
}
