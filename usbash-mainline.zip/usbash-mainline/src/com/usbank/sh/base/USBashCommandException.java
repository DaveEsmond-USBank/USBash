package com.usbank.sh.base;

/**
 * Base exception for FishCommands

 */

public class USBashCommandException extends Exception {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public USBashCommandException () {}

    public USBashCommandException (String s) {
        super(s);
    }
}
