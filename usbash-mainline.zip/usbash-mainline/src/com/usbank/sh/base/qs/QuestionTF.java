package com.usbank.sh.base.qs;

import java.util.List;

import java.util.Iterator;

public class QuestionTF extends Question {
    private String key;
    private String message;
    private String defaultValue;
    private static final String FALSE = "false";
    private static final String TRUE  = "true";

    /**
     * @param key
     * @param message
     * @param defaultValue
     */
    public QuestionTF(String key, String message, String defaultValue) {
        this.key = key;
        this.message = message;
        this.defaultValue = defaultValue;
        this.followOn = null;
    }
    
    public QuestionTF(String key, String message, String defaultValue,String qual) {
        this.key = key;
        this.message = message;
        this.defaultValue = defaultValue;
        this.followOn = null;
        this.qualification = qual;
    }
    
    public QuestionTF(String key, String message, String defaultValue, Question[] followOn) {
        this.key = key;
        this.message = message;
        this.defaultValue = defaultValue;
        this.followOn=followOn;
    }

    public QuestionTF() {}

    public boolean validate(String input) {
        return FALSE.equals(input) || TRUE.equals(input);
    }

    /**
     * @return Returns the defaultValue.
     */
    public String getDefaultValue() {
        return defaultValue;
    }
    /**
     * @param defaultValue The defaultValue to set.
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    /**
     * @return Returns the key.
     */
    public String getKey() {
        return key;
    }
    /**
     * @param key The key to set.
     */
    public void setKey(String key) {
        this.key = key;
    }
    /**
     * @return Returns the message.
     */
    public String getMessage() {
        return message + " {true|false}";
    }
    /**
     * @param message The message to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }
    

    

}
