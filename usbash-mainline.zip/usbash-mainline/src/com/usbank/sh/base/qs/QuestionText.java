package com.usbank.sh.base.qs;


import java.util.ArrayList;
import java.util.List;


public class QuestionText extends Question {
    private String key;
    private String message;
    private String defaultValue;
    
    public QuestionText(String key, String msg, String def) {
        this.key = key;
        this.message = msg;
        this.defaultValue = def;
    	followOn = null;
    }
    
    public QuestionText(String key, String msg, String def,String qual) {
        this.key = key;
        this.message = msg;
        this.defaultValue = def;
    	followOn = null;
    	this.qualification=qual;
    }
    
    public QuestionText(String key, String msg, String def, Question[] f) {
        this.key = key;
        this.message = msg;
        this.defaultValue = def;
    	followOn = f;
    }
    
    public QuestionText() {}
    
    public boolean validate(String input) {
        return input != null && !input.equals("");
    }
    
    /**
     * @return Returns the defaultValue.
     */
    public String getDefaultValue() {
        return defaultValue;
    }
    /**
     * @param defaultValue The defaultValue to set.
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    /**
     * @return Returns the key.
     */
    public String getKey() {
        return key;
    }
    /**
     * @param key The key to set.
     */
    public void setKey(String key) {
        this.key = key;
    }
    /**
     * @return Returns the message.
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message The message to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
