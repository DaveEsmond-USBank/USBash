package com.usbank.sh.base.qs;


import java.util.List;

public class QuestionMC extends Question {
    private String key;
    private String message;
    private String[] choices;
    private String defaultValue;

    /**
     * @param key
     * @param message
     * @param choices
     * @param defaultValue
     */
    public QuestionMC(String key, String message, String[] choices,
            String defaultValue) {
        this.key = key;
        this.message = message;
        this.choices = choices;
        this.defaultValue = defaultValue;
        this.followOn = null;
    }
    public QuestionMC(String key, String message, String[] choices,
            String defaultValue, String qual) {
        this.key = key;
        this.message = message;
        this.choices = choices;
        this.defaultValue = defaultValue;
        this.followOn = null;
        this.qualification=qual;
    }
    public QuestionMC() {}
    public QuestionMC(String key, String message, String[] choices,
            String defaultValue, Question[] followOn) {
        this.key = key;
        this.message = message;
        this.choices = choices;
        this.defaultValue = defaultValue;
        this.followOn = followOn;
    }

    public boolean validate(String input) {
        List l = java.util.Arrays.asList(choices);
        return l.contains(input);
    }
    
    /**
     * @return Returns the choices.
     */
    public String[] getChoices() {
        return choices;
    }
    /**
     * @param choices The choices to set.
     */
    public void setChoices(String[] choices) {
        this.choices = choices;
    }
    /**
     * @return Returns the defaultValue.
     */
    public String getDefaultValue() {
        return defaultValue;
    }
    /**
     * @param defaultValue The defaultValue to set.
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    /**
     * @return Returns the key.
     */
    public String getKey() {
        return key;
    }
    /**
     * @param key The key to set.
     */
    public void setKey(String key) {
        this.key = key;
    }
    /**
     * @return Returns the message.
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message The message to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }
    
}
