package com.usbank.sh.base.qs;


public class QuestionInt extends Question {
    private String key;
    private String message;
    private String defaultValue;
    
    public QuestionInt(String key, String msg, String def) {
        this.key = key;
        this.message = msg;
        this.defaultValue = def;
        this.followOn=null;
    }
    
    public QuestionInt(String key, String msg, String def,String qual) {
        this.key = key;
        this.message = msg;
        this.defaultValue = def;
        this.followOn=null;
        this.qualification=qual;
    }
    
    public QuestionInt(String key, String msg, String def, Question[] fo) {
        this.key = key;
        this.message = msg;
        this.defaultValue = def;
        this.followOn = fo;
    }
    
    public QuestionInt() {}
    
    public boolean validate(String input) {
        try {
            Integer.parseInt(input);
            return true;
        }
        catch (Exception e) {/*gulp*/}
        return false;
    }
    
    /**
     * @return Returns the defaultValue.
     */
    public String getDefaultValue() {
        return defaultValue;
    }
    /**
     * @param defaultValue The defaultValue to set.
     */
    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
    /**
     * @return Returns the key.
     */
    public String getKey() {
        return key;
    }
    /**
     * @param key The key to set.
     */
    public void setKey(String key) {
        this.key = key;
    }
    /**
     * @return Returns the message.
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message The message to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }
	public Question[] getFollowOn() {
		return followOn;
	}

	public void setFollowOn(Question[] followOn) {
		this.followOn = followOn;
	}
}
