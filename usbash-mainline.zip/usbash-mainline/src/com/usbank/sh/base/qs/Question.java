package com.usbank.sh.base.qs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 */
public abstract class Question {
    protected Question[] followOn;
    protected String qualification;

	
    public abstract void setKey(String key);
    public abstract String getKey ();
    public abstract String getMessage();
    public abstract String getDefaultValue();
    public abstract boolean validate(String value);
    
    
    protected boolean isQualified(String answer) {
    	return (  (qualification == null)  ||
    			  (qualification != null && 
    					  qualification.equalsIgnoreCase(answer)));
    }
    
	public List<Question> getFollowOn(String answer) {
		List<Question>retVal = null;
		
		if (followOn == null) return retVal;
		
		retVal = new ArrayList<Question>();
		retVal.addAll(java.util.Arrays.asList(followOn));
		for (Iterator<Question> i=retVal.iterator();i.hasNext();) {
			if (!i.next().isQualified(answer)) {
				i.remove();
			}
		}
		return retVal;
	}

	public void setFollowOn(Question[] followOn) {
		this.followOn = followOn;
	}
	
    public void setQualification (String s) {
    	qualification = s;
    }
    
}
