package com.usbank.sh.excel;

import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.DateUtil;

public abstract class ExcelImporter {

    public abstract void parseBook (String fileName)
    throws WorkbookNotFoundException, WorksheetNotFoundException, 
           WorksheetParseException;
    
    
    @SuppressWarnings("deprecation")
	protected String parseCell (HSSFSheet sheet, int rowNo, int cellNo)
    throws WorksheetParseException 
    {
	    HSSFRow hRow;
	
	    hRow = sheet.getRow(rowNo);
	    if (hRow == null) {
	        throw new WorksheetParseException("Invalid cell: " + 
	                                          rowNo + ":" + cellNo); 
	    }
	    return getCellStringValue(hRow.getCell((short) cellNo));
	}

	protected List<String[]> parseRows (HSSFSheet sheet, int bRow, int rowCount, 
	                          int bCol, int eCol) 
	    throws WorksheetParseException {
	    HSSFRow row;
	    List<String[]> records;
	
	    records = null;
	
	    try {
	        for (int rPos=bRow; rPos<(rPos+rowCount); rPos++) {
	            String[] rec;
	            row = sheet.getRow( rPos );
	
	            if (row == null) { 
	                break; 
	            }
	
	            rec = new String[eCol - bCol + 1];
	            for (int cPos=bCol;cPos<=eCol;cPos++) {
	                @SuppressWarnings("deprecation")
					HSSFCell cell = row.getCell((short)cPos);
	                rec[cPos - bCol] = getCellStringValue(cell);
	            }
	            if (records == null) {
	                records = new ArrayList<String[]>();
	            }
	            records.add(rec);
	        }
	    } catch (Exception e) {
	        // POI mostly throws NullPointer exceptions when things go wrong
	        // This is really bad etiquette. Convert to friendly error.
	        throw new WorksheetParseException("Fatal Error while parsing " +
	                                          "sheet:" + sheet.toString(),e);
	    }
	    return records;
	}
	
	protected String getCellStringValue (HSSFCell cell) 
	    throws WorksheetParseException {
	    String cellValue = "";
	
	    if (cell == null) return cellValue;


	    try {
            switch (cell.getCellType()) {
                case HSSFCell.CELL_TYPE_STRING:
                    cellValue = cell.getStringCellValue();
                    break;
                case HSSFCell.CELL_TYPE_BOOLEAN:
                    cellValue = String.valueOf(cell.getBooleanCellValue());
                    break;
                case HSSFCell.CELL_TYPE_NUMERIC:
                	 
                	
                	
                	if (DateUtil.isCellInternalDateFormatted(cell) || DateUtil.isCellDateFormatted(cell)) {
                		SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
                		cellValue = formatter.format(cell.getDateCellValue());
                	}
                	else {
                		cellValue = String.valueOf(cell.getNumericCellValue());
                	}
                break;
                case HSSFCell.CELL_TYPE_BLANK:
                case HSSFCell.CELL_TYPE_ERROR:
                	cellValue = String.valueOf(cell);
                case HSSFCell.CELL_TYPE_FORMULA:
                	cellValue = handleFormula(cell);
                default:
                // empty String
            }
	    } 
	    catch (Exception e) {
	        throw new WorksheetParseException ("Fatal Error while parsing " +
	                                           "cell:" + cell,e);
	    }
	    return cellValue;
	}
	
	private String handleFormula (HSSFCell cell) {
		CellValue actualValue;
		String retVal = "";
		
        if (evaluator != null && cell !=null) {
        	actualValue = evaluator.evaluate(cell);
      	  
      	    if (actualValue != null) 
      	    {
      	    	if (actualValue.getCellType() == HSSFCell.CELL_TYPE_NUMERIC) 
      	    	{
      	    		if (HSSFDateUtil.isCellInternalDateFormatted(cell) || HSSFDateUtil.isCellDateFormatted(cell)) 
      	    		{
      	    			SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
      	    			Date d = HSSFDateUtil.getJavaDate(actualValue.getNumberValue());
      	    			retVal = formatter.format(d);
      			    }
      	    		else {
      	    			retVal = String.valueOf(cell.getNumericCellValue());
      	    		}
      	    	}
      	    	else {
      	    		retVal = actualValue.formatAsString();
      	    	}
      	    }
        }
        return retVal;
	}
	
	private HSSFFormulaEvaluator evaluator;
	@SuppressWarnings("deprecation")
	protected HSSFFormulaEvaluator getFormulaEvaluator (HSSFWorkbook workbook, HSSFSheet sheet) {
		if (null == evaluator) {
			evaluator = new HSSFFormulaEvaluator(sheet, workbook);
		}
		return evaluator;
	}
	
	protected HSSFSheet getSheet (HSSFWorkbook wb, String name)
	    throws WorksheetNotFoundException {
	    HSSFSheet sheet;
	    sheet = wb.getSheet(name);
	    getFormulaEvaluator(wb,sheet);
	    // POI should be throwing some sort of exc but doesn't
	    // So do it for them.
	    if (sheet == null) {
	        throw new WorksheetNotFoundException ("Fatal Error: " +
	                                              "Missing worksheet - \"" + 
	                                              name + "\"");
	    }
	    return sheet;
	}
	
	protected HSSFWorkbook getBook (String fileName)
	    throws WorkbookNotFoundException {
	    HSSFWorkbook wb;
	    try {
	        POIFSFileSystem fs =
	            new POIFSFileSystem(new FileInputStream(fileName));
	        wb = new HSSFWorkbook(fs);
	    } 
	    catch (/*IO or*/Exception e) {
	        throw new WorkbookNotFoundException("Fatal: Workbook \"" +
	                fileName + "\" not found or invalid.");
	    }
	    return wb;            
	}
	        
	protected boolean isEmpty (String val) {
	    return (val == null || val.trim().compareTo("")==0) ? true : false;
	}
	
    protected Boolean parseBoolean (String bStr) {
    	if (isEmpty(bStr)) { return null; }
    	
    	if (bStr.trim().toLowerCase().equals("yes")) {
    		return Boolean.TRUE;
    	}
    	return Boolean.FALSE;
    }
    
    protected Date parseDate (String date) throws WorksheetParseException {
    	if (isEmpty(date)) return null;
    	try {
    		// Expecting target = "mm/dd/yyyy 28 20:29:30 JST 2000";
    	    DateFormat df = DateFormat.getInstance();
    	    return  df.parse(date);  
    	}
    	catch (Exception e) {
    		throw new WorksheetParseException ("Invalid Date string passed:" 
    	                                       + date,e);
    	}
    }
    
    protected Integer parseInteger (String integerString) throws WorksheetParseException {
    	if (isEmpty(integerString)) return null;
    	    	
    	try {
    		try {
    			return Integer.parseInt(integerString);
    		}
    		catch (NumberFormatException e) {
    			// Be forgiving as Excel loves to turn integers into un-intentional floats
    			return new Integer(parseFloat(integerString).intValue());
    		}
    	}
    	catch (NumberFormatException e) {
    		throw new WorksheetParseException("Invalid integer paassed:" 
    										  + integerString,e);
    	}
    }
    
    protected Float parseFloat (String floatString) throws WorksheetParseException {
    	if (isEmpty(floatString)) return null;
    	
    	try {
    		return Float.parseFloat(floatString);
    	}
    	catch (NumberFormatException e) {
    		throw new WorksheetParseException("Invalid Float paassed:"
    										  + floatString,e);
    	}
    }

}
