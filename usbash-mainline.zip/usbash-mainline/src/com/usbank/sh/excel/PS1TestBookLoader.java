package com.usbank.sh.excel;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.usbank.px1.test.AgentInformation;
import com.usbank.px1.test.MailingAddress;
import com.usbank.px1.test.OfferRecipientDetails;
import com.usbank.px1.test.OrganizationMailingAddress;
import com.usbank.px1.test.PS1Request;
import com.usbank.px1.test.RequestCriteria;

/**
 * PS1TestBookLoader - load an Excel file that contains the different PS1 scenarios.  There are 17 test cases that are
 * addressed by this client.
 * @author dave
 *
 */

public class PS1TestBookLoader extends ExcelImporter  {
    public static final int MAXROWPARSE         = 5000;
    public static final int MAXCOLPARSE         = 500;
	private List<PS1Request> ps1Requests;
	private Double requestCount;
	private List<String>testCaseList;
	private Integer threadCount;
	private Integer threadSleepInterval;
	private String endPointURL;
	private List<String[]>headers;
	
	
    public String getEndPointURL() {
		return endPointURL;
	}


	public List<String[]> getHeaders() {
		return headers;
	}


	public Double getRequestCount() {
		return requestCount;
	}


	public List<String> getTestCaseList() {
		return testCaseList;
	}


	public Integer getThreadCount() {
		return threadCount;
	}


	public Integer getThreadSleepInterval() {
		return threadSleepInterval;
	}


	public void parseBook (String fileName)
    throws WorkbookNotFoundException, WorksheetNotFoundException, 
           WorksheetParseException {
	    
	    HSSFWorkbook wb = getBook(fileName);
	    ps1Requests = new ArrayList<PS1Request>();
	    parseTestBookData(wb);
    }
    
    
    protected void parseTestBookData (HSSFWorkbook wb) 
    	throws WorksheetNotFoundException, WorksheetParseException { 
    	this.parsePS1Settings(wb);
    	this.parsePS1RequestsSheet(wb);
    }
    
    
    protected void parsePS1Settings (HSSFWorkbook wb) 
		throws WorksheetNotFoundException, WorksheetParseException { 
	    HSSFSheet theSheet;
	    List<String[]> currentRow;
	    
	    final String SHEET_SETTINGS    	  			= "Settings";
	    final int OFFSET							= 1;
	    final int COL_PROPERTY    		  			= 0;
	    final int COL_VALUE							= 1;
	   
	    final int SHEET_EPG_ROW_BEGIN 				= 1;
	    final int SHEET_EPG_COL_BEGIN 				= COL_PROPERTY + OFFSET;
	    final int SHEET_EPG_COL_END   				= COL_VALUE + OFFSET;
	    boolean foundHeaders = false;
	    headers = new ArrayList<String[]>();
	    
	    theSheet   = getSheet(wb,SHEET_SETTINGS);
	    currentRow = parseRows (theSheet, 
	    						SHEET_EPG_ROW_BEGIN, 
	    						MAXROWPARSE, 
	    						SHEET_EPG_COL_BEGIN, 
	    						SHEET_EPG_COL_END);

	    for (Iterator<String[]> itr = currentRow.iterator();itr.hasNext(); ) {
	        String[] record = (String[])itr.next();
	        String columnVal;
	        

	        columnVal = record[COL_PROPERTY];
	        if (!isEmpty(columnVal) && columnVal.contains("Test Case List")) {
	        	String value = record[COL_VALUE];
	        	this.testCaseList = PS1TestBookLoader.getDistinctNumbers(value);
	        }
	        else if (!isEmpty(columnVal) && columnVal.contains("Request Count")) {
	        	String value = record[COL_VALUE];
	        	this.requestCount = Double.parseDouble(value);
	        } 
	        else if (!isEmpty(columnVal) && columnVal.contains("Thread Sleep Interval")) {
	        	String value = record[COL_VALUE];
	        	this.threadSleepInterval = Integer.parseInt(value);
	        }
	        else if (!isEmpty(columnVal) && columnVal.contains("Endpoint")) {
	        	String value = record[COL_VALUE];
	        	this.endPointURL = value;
	        }
	        else if (!isEmpty(columnVal) && columnVal.contains("Headers")) {
	        	foundHeaders = true;
	        }
	        else if (foundHeaders) {
	        	if (!isEmpty(columnVal)) {
	        		String[] header = new String[2];
	        		header[0] = columnVal;
	        		String value = record[COL_VALUE];
	        		header[1] = value;
	        		headers.add(header);
	        	}
	        }
	    }
	    
    }
    
    protected static List<String> getDistinctNumberStrings (List<Integer> input) {
    	List<String> testCases = new ArrayList<String>();
    	for (Integer i : input) {
    		testCases.add(String.valueOf(i));
    	}
    	return testCases;
    }
    
    protected static List<String> getDistinctNumbers(String ranges) {

        return getDistinctNumberStrings(        		
        		Arrays.stream(ranges.split(","))
                .map(s -> s.replace(" ", ""))
                .map(Range::new)
                .flatMap(range -> range.render().stream())
                .distinct()
                .sorted()
                .collect(Collectors.toList()));
    }

    private static class Range {
        private int start;
        private int stop;

        public Range(String rangeStr) {
            String[] rangeArray = rangeStr.split("-");
            int length = rangeArray.length;

            if (length < 1 || length > 2) {
                throw new IllegalArgumentException("Wrong number of arguments in a Range: " + length);
            }

            start = Integer.parseInt(rangeArray[0]);
            stop = (length == 1) ? start : Integer.parseInt(rangeArray[1]);

            if (stop < start) {
                throw new IllegalArgumentException("Stop before start!");
            }
        }

        public List<Integer> render() {
            List<Integer> pageList = new ArrayList<>(stop - start + 1);
            for (Integer i = start; i < stop + 1; i++) {
                pageList.add(i);
            }

            return pageList;
        }
    }
    
    
    protected void parsePS1RequestsSheet (HSSFWorkbook wb) 
		throws WorksheetNotFoundException, WorksheetParseException { 
	    HSSFSheet theSheet;
	    List<String[]> currentRow;
	    
	    final String SHEET_PS1REQ    	  			= "PS1Scenarios";
	    final int OFFSET							= 1;
	    final int COL_TC    		  				= 0;
	    final int COL_OFFERTYPE    		  			= 1;
	    final int COL_QUALIFYINGEVENT				= 2;
	    final int COL_PARTNERCAMPAIGNID				= 3;
	    final int COL_PARTNERLINKTAG				= 4;
	    final int COL_OFFERCUSTOMERTYPE				= 5;
	    final int COL_AGENT_SENDEMAILASAGENTFLAG	= 6;
	    final int COL_AGENT_BOOKOFBUSINESSID 		= 7;
	    final int COL_AGENT_ASSOCIATEID				= 8;
	    final int COL_AGENT_FULLNAME				= 9;
	    final int COL_AGENT_TITLE					= 10;
	    final int COL_AGENT_PHONE					= 11;
	    final int COL_AGENT_EMAIL					= 12;
	    final int COL_AGENT_LICENSE					= 13;
	    final int COL_AGENT_FACEBOOKURL				= 14;
	    final int COL_AGENT_AGENTPHOTOURL			= 15;
	    final int COL_AGENT_TWITTERURL				= 16;
	    final int COL_AGENT_LINKEDINURL				= 17;
	    final int COL_ORECIP_ALTERNATEKEY			= 18;
	    final int COL_ORECIP_EXTCUSTID 				= 19;
	    final int COL_ORECIP_ACPI					= 20;
	    final int COL_ORECIP_RECIPIENTTYPE			= 21;
	    final int COL_ORECIP_FIRSTNAME				= 22;
	    final int COL_ORECIP_LASTNAME				= 23;
	    final int COL_ORECIP_ADDRESSLINE1		 	= 24;
	    final int COL_ORECIP_ADDRESSLINE2			= 25;
	    final int COL_ORECIP_CITY					= 26;
	    final int COL_ORECIP_STATE					= 27;
	    final int COL_ORECIP_ZIPCODE				= 28;
	    final int COL_ORECIP_EMAILADDRESS			= 29;
	    final int COL_ORECIP_HOMEPHONE				= 30;
	    final int COL_ORECIP_WORKPHONE				= 31;
	    final int COL_ORECIP_MOBILEPHONE			= 32;
	    final int COL_ORECIPORG_ORGANIZATIONNAME	= 33;
	    final int COL_ORECIPORG_DATEOFBIRTH			= 34;
	    final int COL_ORECIPORG_ADDRESSLINE1		= 35;
	    final int COL_ORECIPORG_ADDRESSLINE2		= 36;
	    final int COL_ORECIPORG_CITY				= 37;
	    final int COL_ORECIPORG_STATE				= 38;
	    final int COL_ORECIPORG_ZIPCODE				= 39;
	    final int SHEET_EPG_ROW_BEGIN 				= 2;
	    final int SHEET_EPG_COL_BEGIN 				= COL_TC + OFFSET;
	    final int SHEET_EPG_COL_END   				= COL_ORECIPORG_ZIPCODE + OFFSET;
	    
	    
	    theSheet   = getSheet(wb,SHEET_PS1REQ);
	    currentRow = parseRows (theSheet, 
	    						SHEET_EPG_ROW_BEGIN, 
	    						MAXROWPARSE, 
	    						SHEET_EPG_COL_BEGIN, 
	    						SHEET_EPG_COL_END);

	    for (Iterator<String[]> itr = currentRow.iterator();itr.hasNext(); ) {
	        String[] record = (String[])itr.next();
	        String columnVal;
	        RequestCriteria req = new RequestCriteria();
	    	AgentInformation agent = new AgentInformation();	    	
	    	MailingAddress mAdd = new MailingAddress();
	    	OrganizationMailingAddress omAdd = new OrganizationMailingAddress();
	    	OfferRecipientDetails ord = new OfferRecipientDetails();
	    	PS1Request ps1Req = new PS1Request();
	    	req.setAgentInformation(agent);
	    	ord.setMailingAddress(mAdd);
	    	ord.setOrganizationMailingAddress(omAdd);
	    	req.setOfferRecipientDetails(ord);
	    	ps1Req.setRequestCriteria(req);

	        columnVal = record[COL_TC];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("Test Case # is required:" 
	        									  + columnVal );
	        }	        
	        ps1Req.setTestCaseNumber (columnVal);

	        columnVal = record[COL_OFFERTYPE];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("Offer Type is required:" 
	        									  + columnVal );
	        }	        
	    	req.setOfferType(columnVal);
	    		    	
	    	columnVal = record[COL_QUALIFYINGEVENT];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("Qualifying Event is required:" 
	        									  + columnVal );
	        }	        
	    	req.setQualifyingEvent(columnVal);
	    	
	    	columnVal = record[COL_PARTNERCAMPAIGNID];
	        if (!isEmpty(columnVal)) {
	        	req.setPartnerCampaignId(columnVal);
	        }	        
	    	
	    	columnVal = record[COL_PARTNERLINKTAG];
	        if (!isEmpty(columnVal)) {
	        	req.setPartnerLinkTag(columnVal);
	        }	
	        
	    	columnVal = record[COL_OFFERCUSTOMERTYPE];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("Offer Customer Type is required:" 
	        									  + columnVal );
	        }	        
	    	req.setOfferCustomerType(columnVal);
	 

	    	columnVal = record[COL_AGENT_SENDEMAILASAGENTFLAG];
	        if (!isEmpty(columnVal)) {
	        	agent.setSendEmailAsAgentFlag(Boolean.parseBoolean(columnVal));
	        }
	        else {
	        	agent.setSendEmailAsAgentFlag(Boolean.FALSE);
	        }
	    	

	    	columnVal = record[COL_AGENT_BOOKOFBUSINESSID];
	        if (!isEmpty(columnVal)) {
	        	agent.setBookOfBusinessId(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_ASSOCIATEID];
	        if (!isEmpty(columnVal)) {
	        	agent.setAssociateId(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_FULLNAME];
	        if (!isEmpty(columnVal)) {
	        	agent.setFullName(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_TITLE];
	        if (!isEmpty(columnVal)) {
	        	agent.setTitle(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_PHONE];
	        if (!isEmpty(columnVal)) {
	        	agent.setPhone(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_EMAIL];
	        if (!isEmpty(columnVal)) {
	        	agent.setEmail(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_LICENSE];
	        if (!isEmpty(columnVal)) {
	        	agent.setLicense(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_FACEBOOKURL];
	        if (!isEmpty(columnVal)) {
	        	agent.setFaceBookURL(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_AGENTPHOTOURL];
	        if (!isEmpty(columnVal)) {
	        	agent.setAgentPhotoUrl(columnVal);
	        }	
	        
	    	columnVal = record[COL_AGENT_TWITTERURL];
	        if (!isEmpty(columnVal)) {
	        	agent.setTwitterURL(columnVal);
	        }	
	        
	        columnVal = record[COL_AGENT_LINKEDINURL];
	        if (!isEmpty(columnVal)) {
	        	agent.setLinkedInURL(columnVal);
	        }		        
	    	
	    	String aKey  = record[COL_ORECIP_ALTERNATEKEY];
	    	String mktID = record[COL_ORECIP_EXTCUSTID];
	    	String acpi  = record[COL_ORECIP_ACPI];

	        if (isEmpty(aKey) && isEmpty(mktID) && isEmpty(acpi)) {
	        	throw new WorksheetParseException("At least one unique ID is required for recipient:" );
	        }
	        if (!isEmpty(aKey)) {
	        		ord.setAlternateKey(aKey);
	        }
	        if (!isEmpty(mktID)) {
        		ord.setExternalId(mktID);
	        }	    	
	        if (!isEmpty(acpi)) {
        		ord.setAcpi(acpi);
	        }
	        
	    	columnVal = record[COL_ORECIP_EMAILADDRESS];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("E-Mail Address is required:" 
	        									  + columnVal );
	        }	        
	    	ord.setEmailAddress(columnVal);
	    	
	    	
	    	columnVal = record[COL_ORECIP_FIRSTNAME];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("First Name is required:" 
	        									  + columnVal );
	        }	        
	    	ord.setFirstName(columnVal);

	    	columnVal = record[COL_ORECIP_LASTNAME];
	        if (isEmpty(columnVal)) {
	        	throw new WorksheetParseException("Last Name is required:" 
	        									  + columnVal );
	        }	        
	    	ord.setLastName(columnVal);

	    	
	        columnVal = record[COL_ORECIP_HOMEPHONE];
	        if (!isEmpty(columnVal)) {
	        	ord.setHomePhone(columnVal);
	        }		        

	        columnVal = record[COL_ORECIP_MOBILEPHONE];
	        if (!isEmpty(columnVal)) {
	        	ord.setMobilePhone(columnVal);
	        }		        

	        columnVal = record[COL_ORECIPORG_ORGANIZATIONNAME];
	        if (!isEmpty(columnVal)) {
	        	ord.setOrganizationName(columnVal);
	        }		        

	        ;
	        columnVal = record[COL_ORECIP_RECIPIENTTYPE];
	        if (isEmpty(columnVal) || 
	        		(!"P".equals(columnVal) && !"O".equals(columnVal))) {
	        	throw new WorksheetParseException("Recipient Type (P or O) is required:" 
						  + columnVal );
	        }		    
        	ord.setRecipientType(columnVal);


	        columnVal = record[COL_ORECIP_WORKPHONE];
	        if (!isEmpty(columnVal)) {
	        	ord.setWorkPhone(columnVal);
	        }		        

	        columnVal = record[COL_ORECIPORG_DATEOFBIRTH];
	        if (!isEmpty(columnVal)) {
	        	ord.setDateOfBirth(columnVal);
	        }		        

		    String line1 = record[COL_ORECIP_ADDRESSLINE1];
		    String line2 = record[COL_ORECIP_ADDRESSLINE2];
		    String city = record[COL_ORECIP_CITY];
		    String state = record[COL_ORECIP_STATE];
		    String zip = record[COL_ORECIP_ZIPCODE];
	    	mAdd.setAddressLine1(line1);
	    	mAdd.setAddressLine2(line2);
	    	mAdd.setCity(city);
	    	mAdd.setState(state);
	    	mAdd.setZipCode(zip);

		    line1 = record[COL_ORECIPORG_ADDRESSLINE1];
		    line2 = record[COL_ORECIPORG_ADDRESSLINE2];
		    city = record[COL_ORECIPORG_CITY];
		    state = record[COL_ORECIPORG_STATE];
		    zip = record[COL_ORECIPORG_ZIPCODE];
	    	omAdd.setAddressLine1(line1);
	    	omAdd.setAddressLine2(line2);
	    	omAdd.setCity(city);
	    	omAdd.setState(state);
	    	omAdd.setZipCode(zip);
	    	
	    	ps1Requests.add(ps1Req);

 	    }
	    
    }


	public List<PS1Request> getPs1Requests() {
		return ps1Requests;
	}
    
	public static void main(String[] args) throws Exception {    	
		PS1TestBookLoader loader = new PS1TestBookLoader();
    	try {
    		loader.parseBook("/Users/dave/eclipse-workspace/USBash/usbash-mainline/etc/PS1_Scenarios.xls");
    	} 
    	catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    
}

    
    
 



