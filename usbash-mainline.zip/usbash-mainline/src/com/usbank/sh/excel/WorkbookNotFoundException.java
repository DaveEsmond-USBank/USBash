package com.usbank.sh.excel;

/**
 * Thrown when the workbook is missing or invalid.
 * @author desmond
 */
public class WorkbookNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	/**
     * @param message
     */
    public WorkbookNotFoundException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public WorkbookNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
