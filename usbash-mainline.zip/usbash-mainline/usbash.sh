#!/bin/bash

# ***** OK TO EDIT THESE ******

export        JAVA_HOME=/Library/Java/JavaVirtualMachines/jdk1.8.0_92.jdk
export       SHELL_HOME=/Users/dave/eclipse-workspace/USBash/usbash-mainline
export     USBASH_HISTORY=/tmp/usbash.log
export  SHELL_RUNSOURCE=./bin/usbash.jar

# ***** DO NOT EDIT BELOW THIS LINE ******
export USBASH_LIB=$SHELL_HOME/lib
export SHELL_BITS=./bin
export JLINEJAR=$USBASH_LIB/jline.jar
export POIJAR=$USBASH_LIB/poi.jar
export GSONJAR=$USBASH_LIB/gson-2.8.5.jar
export LOG4JJAR=$USBASH_LIB/log4j-1.2.14:$USBASH_LIB/log4j.jar:$USBASH_LIB/commons-logging.jar
export APACHE_HTTPCLIENT=$USBASH_LIB/httpclient.jar:$USBASH_LIB/httpcore.jar
export USBASH_CLASS=com.usbank.sh.base.cmd.USBash

export SHELL_CP=$JLINEJAR:$COMMONSPOOL:$COMMONSLOG:$APACHE_HTTPCLIENT:$COMMONSDISC:$LOG4JJAR:$POIJAR:$GSONJAR:$SHELL_HOME:$SHELL_RUNSOURCE:$COMMONSLIBJAR

export SYS_PROPS="-Dorg.apache.commons.logging.LogFactory=org.apache.commons.logging.impl.LogFactoryImpl -Dorg.apache.commons.logging.Log=org.apache.commons.logging.impl.NoOpLog"
export HISTORY_PROPS="-Dshell-history-file=$USBASH_HISTORY"
export DEBUG="-Xdebug -Xrunjdwp:transport=dt_socket,address=8002,suspend=n,server=y"

"$JAVA_HOME/Contents/Home/bin/java" $SYS_PROPS $HISTORY_PROPS $DBPROPS -cp $SHELL_CP $DEBUG $USBASH_CLASS
