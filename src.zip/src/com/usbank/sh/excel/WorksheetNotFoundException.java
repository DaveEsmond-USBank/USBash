package com.usbank.sh.excel;

/**
 * Thrown when the worksheet is missing.
 * @author desmond
 */
public class WorksheetNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

    /**
     * @param message
     */
    public WorksheetNotFoundException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public WorksheetNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
