package com.usbank.sh.excel;

/**
 * Throw for various parsing related reasons.
 * @author desmond
 */
public class WorksheetParseException extends Exception {

	private static final long serialVersionUID = 1L;

    /**
     * @param message
     */
    public WorksheetParseException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public WorksheetParseException(String message, Throwable cause) {
        super(message, cause);
    }

}
