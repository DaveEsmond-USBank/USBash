package com.usbank.sh.base.cmd;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.log4j.Logger;

import com.usbank.px1.test.CustomTrustManager;

public class PX1HttpClient {
    private static Logger log =
            Logger.getLogger(PX1HttpClient.class);

	public PX1HttpClient() {
	}
	

	public void post (String url, List<String[]>headers, String payload) {
        HttpClient client;
        HttpPost request;
        HttpResponse response;
        
        try {
        	if (url.contains("HTTPS")) {
        		CustomTrustManager.initSsl();
        	}
        	client 	= (url.contains("https") || url.contains("HTTPS")) ? getTLSClient() : getClient();
        	request = new HttpPost(url);

        	if (headers != null) {
	        	for (String[] header : headers) {
	                request.addHeader(header[0], header[1]);
	        	}
        	}
        	
        	StringEntity entity = new StringEntity(payload,ContentType.APPLICATION_JSON);
        	request.setEntity(entity);
        	
        	log.debug("REQUEST:" + request);

            response = client.execute(request);

            BufferedReader br = new BufferedReader(
                             new InputStreamReader((response.getEntity().getContent())));

            String output;
            log.debug("RESPONSE:\n");
            while ((output = br.readLine()) != null) {
            	log.debug(output);
            }
		} 
        catch (Exception e) 
        {
			e.printStackTrace();
		} 
    }
	
	public HttpClient getClient () throws ClientProtocolException, IOException {
        return HttpClientBuilder.create().build();
	}
	
	public CloseableHttpClient getTLSClient () 
			throws ClientProtocolException, IOException, KeyStoreException, 
			       KeyManagementException, NoSuchAlgorithmException {
		
		SSLContext sslContext = SSLContexts.custom()
		        .loadTrustMaterial((chain, authType) -> true).build();

		SSLConnectionSocketFactory sslConnectionSocketFactory =
		        new SSLConnectionSocketFactory(sslContext, new String[]
		        {"SSLv2Hello", "SSLv3", "TLSv1","TLSv1.1", "TLSv1.2" }, null,
		        NoopHostnameVerifier.INSTANCE);
		CloseableHttpClient client = HttpClients.custom()
		        .setSSLSocketFactory(sslConnectionSocketFactory)
		        .build();
		
		return client;
		
	}
}
