package com.usbank.sh.base.cmd;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

public class PX1UniRESTClient {
	private static Logger log =
            Logger.getLogger(PX1UniRESTClient.class);
	
	
	public PX1UniRESTClient() {
		// TODO Auto-generated constructor stub
	}
	
	public void post (String url, List<String[]>headers, String payload) {
		Map<String, String> headerMap;
		
		headerMap = new HashMap<String, String>();
    	if (headers != null) {
        	for (String[] header : headers) {
        		headerMap.put(header[0], header[1]);
        	}	
    	}
    	
    	try {
    		System.out.println("REQUEST:" + payload);
        	log.debug("REQUEST:" + payload);
        	
        	//BEGIN HACK
        	SSLContext sslContext = SSLContexts.custom()
        			.loadTrustMaterial(null,new TrustSelfSignedStrategy())
        			.build();
        	@SuppressWarnings("deprecation")
			SSLConnectionSocketFactory sslsf = 
        			new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        	
        	CloseableHttpClient httpclient = HttpClients.custom()
        			.setSSLSocketFactory(sslsf)
        			.build();
        	Unirest.setHttpClient(httpclient);
        	
    		//Unirest.setTimeouts(0, 0);
    		
    		// END HACK
    		
    		HttpResponse<String> response = Unirest.post(url)
    				.headers(headerMap)
    				.body(payload)
    				.asString();
    		
    		log.debug("---------------------RESPONSE DATA------------------------");
    		log.debug("STATUS:"+response.getStatus() + "-" + response.getStatusText());
    		System.out.println(response.getStatus() + "-" + response.getStatusText());
    		log.debug("RESPONSE HEADERS:"+response.getHeaders());
    		
    		// Basic assumption here that any 2XX response will mean
    		// success and we should expect a JSON response that we can
    		// pretty print. Otherwise, assume some XML or junk response
    		// that we'll just spit out raw.
    		System.out.println("RESPONSE:");
    		if (response.getStatus() >= 200 &&
    				response.getStatus() < 300) {
    			
    			Gson gson = new GsonBuilder().setPrettyPrinting().create();
    			JsonParser parser = new JsonParser();
    	        String jsonString = 
    	        		gson.toJson(parser.parse(response.getBody()));
        		log.debug("FORMATTED RESPONSE BODY:\n"+jsonString);
        		System.out.println(jsonString);

    		}
    		else {
    			BufferedReader br = new BufferedReader(
                        new InputStreamReader((response.getRawBody())));

    		   String output;
    		   log.debug("NON-JSON RESPONSE:\n");
    		   while ((output = br.readLine()) != null) {
    		   		log.debug(output);
    		   		System.out.println(output);
    		   }
    		}
    		
    	}
    	catch (Exception e) {
    		log.debug(e);
    		e.printStackTrace();
    		log.error(e);
    	}
	}
	

}

