package com.usbank.sh.base.cmd;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.usbank.sh.base.USBashCmdBase;
import com.usbank.sh.base.USBashCommand;
import com.usbank.sh.base.USBashCommandException;

/**
 * USBash command for handling command specific help.
 */

public class Cmd_help extends USBashCmdBase {

    public void doCommand ( String[] args )
        throws USBashCommandException {
        USBashCommand cmd;
        String helpStr;
        PrintStream out;
                
        out = this.getOutStream();
        
        cmd = (args.length>1) ? shellBase.getCommand(args[1]) : this ;
        
        if (null == cmd) {
        	helpStr = "\n\nError: Command not defined. Hit tab for "
        		      + "menu of commands.\n\n";
        }
        else {

	        helpStr = "\n\n"
	        + "----------------------------------------------------------\n"
	    	+ "Help for command: "+cmd.getCommandName()+"\n"
	    	+ "----------------------------------------------------------\n"
	    	+ wrapText(cmd.getHelp(args),60)
	    	+ "\n\n"
	    	+ cmd.getUsage()
	    	+ "----------------------------------------------------------\n"
	    	+ "\n\n";
        }
        
        out.println(helpStr);
    }

    public String getUsage(){
        return formatUsage(this,"<command>");
    }
    
    /** Commands should pass a non-formatted text string
     *  that describes how to use the command.  
     *  args - String array of arguments 
     */
    public String getHelp(String[] args){
        return "Show the help page for the specified command";
    }
    
    private String wrapText (String text, int len)
    {
      // return empty array for null text
      if (text == null || len<=0)
    	  return new String();

      // return text if less than length
      if (text.length() <= len)
    	  return text;

      char [] chars = text.toCharArray();
      List<String> lines = new ArrayList<String>();
      StringBuffer line = new StringBuffer();
      StringBuffer word = new StringBuffer();

      for (int i = 0; i < chars.length; i++) {
        word.append(chars[i]);

        if (chars[i] == ' ') {
          if ((line.length() + word.length()) > len) {
            lines.add(line.toString());
            line.delete(0, line.length());
          }

          line.append(word);
          word.delete(0, word.length());
        }
      }

      // handle any extra chars in current word
      if (word.length() > 0) {
        if ((line.length() + word.length()) > len) {
          lines.add(line.toString());
          line.delete(0, line.length());
        }
        line.append(word);
      }

      // handle extra line
      if (line.length() > 0) {
        lines.add(line.toString());
      }

      String j = "";
      for (Iterator<String> i = lines.iterator();i.hasNext();) {
        j += i.next() + "\n";
      }
      return j;
    }    
    
    
    
}