package com.usbank.sh.base.qs;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.usbank.sh.base.USBashBase;


public class QuestionSet {
    List questions;
    Map answers;
    
    public QuestionSet() {
        questions = new ArrayList();
        answers = new HashMap();
    }
    
    public void addQuestion (Question q) {
        questions.add(q);
    }
    
    public void addTextQuestion(String key, 
                                String msg, String defValue) {
        questions.add( new QuestionText(key,msg,defValue) );
    }
    
    public void addChoiceQuestion (String key,
                                   String msg, String[] list, String def) {
        questions.add( new QuestionMC(key,msg,list,def) );
        
    }
    
    public void addTrueFalse (String key, String msg, String def) {
        questions.add( new QuestionTF(key,msg,def) );
    }

    	
    public void ask( USBashBase prompter ) throws Exception {
    	ask (prompter,questions);
    }
    
	public void ask( USBashBase prompter, List children) throws Exception {
		
		if (null == children) {
			return;
		}
		
        for (Iterator i=children.iterator();i.hasNext();) {
            Question thisQ = (Question)i.next();
            String answer;
            do {
                answer = 
                    prompter.getInput( formatDefault(thisQ.getKey(),
                                                     thisQ.getMessage(),
                                                     thisQ.getDefaultValue()),
                                       false/*add to shell history*/);
                if (answer.equals("")) {
                    answer =
                        getCurrentOrDefault( 
                            thisQ.getKey(),thisQ.getDefaultValue());
                }
                answers.put(thisQ.getKey(),answer);
            } while (! thisQ.validate(answer));
            ask (prompter,thisQ.getFollowOn(answer));
        }
    }
    
    public String getAnswer (String questionKey) {
        return (String)answers.get(questionKey);
    }
    
    public void setAnswers(Map m) {
        this.answers = m;
    }
    
    protected String getCurrentOrDefault (String key, String def) {
        if (answers.containsKey(key) && null != answers.get(key) ){
            return (String) answers.get(key);
        }
        return def;
    }
    
    public String formatDefault (String key, String msg, String def) {
        return msg + " [" 
                   + getCurrentOrDefault(key,def)  
                   + "]:";
    }
    
    public String toString() {
        StringBuffer sb;
        sb = new StringBuffer();
        sb.append("QuestionSet:");
        for (Iterator i=questions.iterator();i.hasNext();) {
            Question q = (Question)i.next();
            sb.append("[")
              .append(q.getKey())
              .append(":=:")
              .append(answers.get(q.getKey()))
              .append("]");
        }
        return sb.toString();
    }
}
