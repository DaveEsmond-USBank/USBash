package com.usbank.sh.base;

import sun.misc.Signal;
import sun.misc.SignalHandler;

/**
 * SigHandler - handle graceful shutdown for
 * interrupt signal.
 */
public class SigHandler implements SignalHandler {
    public  final static int SIGNAL_INT = 1;
    private static String SIGNAL_INT_NAME = "INT";
    private static USBashBase handlerShell;
    
    public static void install(USBashBase shell, int signalNo) {
        Signal signal;
        
        handlerShell = shell;
        
        switch (signalNo) {
            case SIGNAL_INT:
                signal = new Signal(SIGNAL_INT_NAME);
                break;
            default:
                throw new IllegalArgumentException(
                        "unsupported signal: "+signalNo);
        }
        try {
            Signal.handle(signal, new SigHandler());
        } catch(Exception e) {
            System.err.println(e);
        }
    }

    public void handle(Signal signal) {
        if (signal.getName().equals(SigHandler.SIGNAL_INT_NAME)) {
            Signal.handle(signal, SIG_IGN);
            handlerShell.shutdown();
            Runtime.getRuntime().halt(0);
        }
    }
}
