package com.usbank.px1.test;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class RequestManager {

    private static List<PS1RequestThread> requestThreads;
    private static RequestManager singleton;
    private Double requestCount;
    private List<PS1Request> testCaseList;
    private Integer threadSleep;
    private String endPointURL;
    private List<String[]> headers;
    
    
    public static RequestManager getInstance() {
        if (singleton == null) {
            singleton = new RequestManager();
        }
        return singleton;        
    }
    
    private RequestManager () {}
    
    public void init (	Double requestCount, List<PS1Request> testCaseList, 
    				    Integer threadSleep, String endPointURL, List<String[]> headers) {
        requestThreads = new ArrayList<PS1RequestThread>(testCaseList.size());
        this.requestCount = requestCount;
        this.testCaseList = testCaseList;
        this.threadSleep = threadSleep;
        this.endPointURL = endPointURL;
        this.headers = headers;
    }
    
    private String jsonify (PS1Request req) {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(req);
    }
   
    protected void startRequests () {
        PS1RequestThread st;
        
        for (PS1Request req : testCaseList) {
            String pJson = jsonify(req);

        	try {
                st = new PS1RequestThread (req.getTestCaseNumber(),pJson,endPointURL,requestCount,headers,threadSleep);
                Thread t = new Thread(st);
                t.start();
                requestThreads.add(st);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void stopAll() {
    	if (requestThreads != null) {
	    	for (PS1RequestThread r : requestThreads) {
	    		r.setShouldRun(false);
	    	}
    	}
    }  
    
}
