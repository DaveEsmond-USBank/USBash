package com.usbank.px1.test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DynamicDataHelper {

	private DynamicDataHelper() {
	}

	public static String processDynamicVars (String body) {
		
		// We have a predefined list of stuff we're expecting.
		
		Pattern pattern = Pattern.compile("(\\\\u003cRANDOM10\\\\u003e)");
		Matcher matcher = pattern.matcher(body);
		
		int lastIndex = 0;
		StringBuilder output = new StringBuilder();
		while (matcher.find()) {
		    output.append(body, lastIndex, matcher.start())
		      .append(getRandom10());

		    lastIndex = matcher.end();
		}
		if (lastIndex < body.length()) {
		    output.append(body, lastIndex, body.length());
		}
		return output.toString();		
		
	}
	
	private static long getRandom10 () {
		return (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
	}
	
	  public static void main(String[] args) {

		  //String theString = "{ \"jsonVal\" : { \"foo\": \"bar\", \"kid\":\"<RANDOM10>\" }, \"yes\" : \"<RANDOM10>\" }";
		  String theString = "{ \"jsonVal\" : { \"foo\": \"bar\", \"kid\":\"\\u003cRANDOM10\\u003e\" }, \"yes\" : \"\\u003cRANDOM10\\u003e\" }";
		  System.out.println("BEFORE: " + theString);
		  theString = DynamicDataHelper.processDynamicVars(theString);
		  System.out.println("AFTER: " + theString);
	  }
}
