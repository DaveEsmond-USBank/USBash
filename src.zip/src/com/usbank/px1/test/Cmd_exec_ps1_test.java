package com.usbank.px1.test;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.usbank.sh.base.USBashCmdBase;
import com.usbank.sh.base.USBashCommandException;
import com.usbank.sh.excel.PS1TestBookLoader;

public class Cmd_exec_ps1_test extends USBashCmdBase {
	   private static Logger log =
	            Logger.getLogger(USBashCmdBase.class);

	   public void doCommand ( String[] args ) throws USBashCommandException {
	        getOutStream().println("PS1 Test");
	        
	       if (args.length != 2 && args.length != 3) {
	            getOutStream().println(getUsage());
	       }
	        
	        // exec-ps1 load <filename>
	        // exec-ps1 list
	        // exec-ps1 start
	        // exec-ps1 stop
	        
	        if ("load".equals(args[1])) {
		        
		        try {
			        PS1TestBookLoader loader = new PS1TestBookLoader ();
			        loader.parseBook(args[2]);
			        List<PS1Request> requests = loader.getPs1Requests();
			        List<PS1Request> includeSet = new ArrayList<PS1Request>();
			        
		        	// Loop through requests to see which ones the test author wants to include in this run
		        	for (PS1Request req : requests) {
		        		if (loader.getTestCaseList().contains(req.getTestCaseNumber())){
		        			includeSet.add(req);
		        		}
		        	}
		        	
		        	PS1RequestConfig config = new PS1RequestConfig();
		        	config.endPointURL = loader.getEndPointURL();
		        	config.requestCount = loader.getRequestCount();
		        	config.headers = loader.getHeaders();
		        	config.threadSleepInterval = loader.getThreadSleepInterval();
		        	config.includeSet = includeSet;
		        	super.saveObject("PS1RequestConfig", config);
		        	
		        	getOutStream().println("Configuration Loaded:");
		        	log.debug("Configuration Loaded");

		        }
		        catch (Exception e) {
		        	//throw new USBashCommandException("Error parsing the excel book:" + e.getMessage());
		        	e.printStackTrace();
		        	log.error(e);;
		        }
		        	
	        }
	        else if ("print".equals(args[1])) {
	        	
	        	PS1RequestConfig config = (PS1RequestConfig) super.getObject("PS1RequestConfig");
	        	if (null == config) {
	        		throw new USBashCommandException ("PS1 Test Configuration Not Loaded");
	        	}
	        	
	        	getOutStream().println("PS1 Test Configuration\n-------------------------------------");
	        	getOutStream().println("Request Count:" + config.requestCount);
	        	getOutStream().println("Thread Sleep:" + config.threadSleepInterval);
	        	getOutStream().println("End Point URL:" + config.endPointURL);
	        	getOutStream().println("Headers:" + concatHeaders(config.headers));
	        	getOutStream().println("Test Cases:" + concatRequests(config.includeSet));
	        	
	        	log.debug("PS1 Test Configuration\n-------------------------------------");
	        	log.debug("Request Count:" + config.requestCount);
	        	log.debug("Thread Sleep:" + config.threadSleepInterval);
	        	log.debug("End Point URL:" + config.endPointURL);
	        	log.debug("Headers:" + concatHeaders(config.headers));
	        	log.debug("Test Cases:" + concatRequests(config.includeSet));

	        	
	        	for (PS1Request req : config.includeSet) {
		        	String pJson = jsonify(req);
		        	getOutStream().println(pJson);
		        	log.debug(pJson);
		        }

	        }
	        else if ("start".equals(args[1])) {
	        	
	        	PS1RequestConfig config = (PS1RequestConfig) super.getObject("PS1RequestConfig");
	        	if (null == config) {
	        		throw new USBashCommandException ("PS1 Test Configuration Not Loaded");
	        	}
	        	
	        	getOutStream().println("PS1 Test Configuration\n-------------------------------------");
	        	getOutStream().println("Request Count:" + config.requestCount);
	        	getOutStream().println("Thread Sleep:" + config.threadSleepInterval);
	        	getOutStream().println("End Point URL:" + config.endPointURL);
	        	getOutStream().println("Headers:" + concatHeaders(config.headers));
	        	getOutStream().println("Test Cases:" + concatRequests(config.includeSet));
	        	log.debug("PS1 Test Configuration\n-------------------------------------");
	        	log.debug("Request Count:" + config.requestCount);
	        	log.debug("Thread Sleep:" + config.threadSleepInterval);
	        	log.debug("End Point URL:" + config.endPointURL);
	        	log.debug("Headers:" + concatHeaders(config.headers));
	        	log.debug("Test Cases:" + concatRequests(config.includeSet));
	        	
	        	// For the tests to be included, go ahead and schedule.
	        	RequestManager man = RequestManager.getInstance();
	        	man.init(	config.requestCount, 
	        				config.includeSet, 
	        				config.threadSleepInterval,
	        				config.endPointURL,
	        				config.headers  );
	        	man.startRequests();
	        }
	        
	        else if ("stop".equals(args[1])) {
	        	getOutStream().println("Stopping requests...");
	        	log.debug("Stopping requests...");
	        	RequestManager man = RequestManager.getInstance();
	        	man.stopAll();
	        	getOutStream().println("Done.");
	        }
	    }
	   
	   private String concatHeaders (List<String[]> list) {
		   StringBuffer sb = new StringBuffer("[");
		   for (String[] i : list) {
			   sb.append("{").append(i[0]).append("=").append(i[1]).append("}");
		   }
		   sb.append("]");
		   return sb.toString();		   
	   }
	   
	   private String concatRequests (List<PS1Request> list) {
		   StringBuffer sb = new StringBuffer("[");
		   for (PS1Request i : list) {
			   sb.append(i.getTestCaseNumber()).append(",");
		   }
		   sb.append("]");
		   return sb.toString();		   
	   }
	   
	   private String jsonify (PS1Request req) {
	        Gson gson = new GsonBuilder().setPrettyPrinting().create();
	        return gson.toJson(req);

	   }
	    	    
	    public String getUsage(){
	        return formatUsage(this,
	        		
	        		  "exec-ps1 load <filename>  (to load test cases)\n"
	        		+ "exec-ps1 list             (to show loaded test cases)\n"
	        		+ "exec-ps1 start            (to start running test cases)\n"
	        		+ "exec-ps1 stop             (to stop running test cases)\n"
	        		+ 
	                "\nFor example:\n" +
	                "    "+ this.getCommandName() +" c:/temp/PS1Scenarios.xls" );        
	    }
	    
	    public String getHelp ( String[] args ) {
	     
	    	return 	"This command reads a Test Scenarios Excel workbook for PS1 " +
	    			"requests and executes the test scenarios.";
	    }  

}

class PS1RequestConfig {
	List<PS1Request> requests;
    List<PS1Request> includeSet;
    Double requestCount;
    Integer threadSleepInterval;
    String endPointURL;
    List<String[]>headers;
}
