package com.usbank.px1.test;

public class RequestCriteria {

	public RequestCriteria() {
	}
	
	private String offerType;
	private String offerProductType;
	private String qualifyingEvent;
	private String partnerCampaignId;
	
	private String partnerLinkTag;
	private String offerCustomerType;
	private AgentInformation agentInformation;
	private OfferRecipientDetails offerRecipientDetails;
	
	public String getOfferType() {
		return offerType;
	}
	public void setOfferType(String offerType) {
		this.offerType = offerType;
	}
	public String getOfferProductType() {
		return offerProductType;
	}
	public void setOfferProductType(String offerProductType) {
		this.offerProductType = offerProductType;
	}
	public String getQualifyingEvent() {
		return qualifyingEvent;
	}
	public void setQualifyingEvent(String qualifyingEvent) {
		this.qualifyingEvent = qualifyingEvent;
	}
	public String getPartnerCampaignId() {
		return partnerCampaignId;
	}
	public void setPartnerCampaignId(String partnerCampaignId) {
		this.partnerCampaignId = partnerCampaignId;
	}
	public String getPartnerLinkTag() {
		return partnerLinkTag;
	}
	public void setPartnerLinkTag(String partnerLinkTag) {
		this.partnerLinkTag = partnerLinkTag;
	}
	public String getOfferCustomerType() {
		return offerCustomerType;
	}
	public void setOfferCustomerType(String offerCustomerType) {
		this.offerCustomerType = offerCustomerType;
	}
	public AgentInformation getAgentInformation() {
		return agentInformation;
	}
	public void setAgentInformation(AgentInformation agentInformation) {
		this.agentInformation = agentInformation;
	}
	public OfferRecipientDetails getOfferRecipientDetails() {
		return offerRecipientDetails;
	}
	public void setOfferRecipientDetails(OfferRecipientDetails offerRecipientDetails) {
		this.offerRecipientDetails = offerRecipientDetails;
	}
	@Override
	public String toString() {
		return "RequestCriteria [offerType=" + offerType + ", offerProductType=" + offerProductType
				+ ", qualifyingEvent=" + qualifyingEvent + ", partnerCampaignId=" + partnerCampaignId
				+ ", partnerLinkTag=" + partnerLinkTag + ", offerCustomerType=" + offerCustomerType
				+ ", agentInformation=" + agentInformation + ", offerRecipientDetails=" + offerRecipientDetails
				+ "]";
	}
		

}
